'use strict';
var Alexa = require('alexa-sdk');

var APP_ID = undefined; //OPTIONAL: replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";
var SKILL_NAME = 'Whale Shark Facts';

/**
 * Array containing space facts.
 */
var FACTS = [
    "Whale sharks have patterns around their gill area and are unique to each shark just like how fingerprints are different on humans.",
    "The size of a whale shark can range from around 5 and a half meters to 10 meters.",
    "The largest whale shark was 12.2 meters long but the whale shark is thought to be able to grow even larger than that!",
    "Whale sharks favorite meal is plankton. Yum",
    "The whale shark species originated about 60 million years ago. Woah! ",
    "Believe it or not, the whale shark is not a whale. It's only called that because of the fish's size.",
    "The whale shark is one of the three known filter feeding sharks. ",
    "The whale shark is a vulnerable species. ",
    "Whale sharks are prefer warm waters and populate all tropical seas.",
    "The whale shark is the largest known extant fish species on the planet.",
    "Whale sharks are estimated to live seventy or more years.",
    "The only known predator of the whale shark are humans.",
    "Whale sharks are docile and sometimes even allow swimmers to swim with them.",
    "Whale shark parts are used in traditional Chinese medicine."
];

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        this.emit('GetFact');
    },
    'GetNewFactIntent': function () {
        this.emit('GetFact');
    },
    'GetFact': function () {
        // Get a random space fact from the space facts list
        var factIndex = Math.floor(Math.random() * FACTS.length);
        var randomFact = FACTS[factIndex];

        // Create speech output
        var speechOutput = "Here is your whale shark fact: " + randomFact;

        this.emit(':tellWithCard', speechOutput, SKILL_NAME, randomFact)
    },
    'AMAZON.HelpIntent': function () {
        var speechOutput = "Do you wwant to learn about whale sharks?";
        var reprompt = "Do you want to learn more about whale sharks?";
        this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', 'See you later, dude.');
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', 'Peace out, yo');
    }
};
