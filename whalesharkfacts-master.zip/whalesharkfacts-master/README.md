# whalesharkfacts
Alexa skill that tells you facts about whale sharks

Images for icon done by Chloe Ng
